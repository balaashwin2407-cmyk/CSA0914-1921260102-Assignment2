public class SharedLogDemo {
    static final int THREADS = 8, PER_THREAD = 200_000;
    interface Appender { void add(String s); int length(); }
    static String trial(Appender a) throws Exception {
        final String[] error = {null};
        Thread[] ts = new Thread[THREADS];
        for (int i = 0; i < THREADS; i++) {
            ts[i] = new Thread(() -> {
                try { for (int k = 0; k < PER_THREAD; k++) a.add("x"); }
                catch (Throwable e) { error[0] = e.getClass().getSimpleName(); }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        return a.length() + (error[0] != null ? " (thread died: " + error[0] + ")" : "");
    }
    public static void main(String[] args) throws Exception {
        int expected = THREADS * PER_THREAD;
        System.out.println("Expected length after " + THREADS + " threads x " + PER_THREAD + " appends = " + expected);
        for (int t = 1; t <= 5; t++) {
            StringBuilder sb = new StringBuilder(); StringBuffer sf = new StringBuffer();
            String r1 = trial(new Appender() { public void add(String s) { sb.append(s); } public int length() { return sb.length(); } });
            String r2 = trial(new Appender() { public void add(String s) { sf.append(s); } public int length() { return sf.length(); } });
            System.out.println("Trial " + t + ": StringBuilder length=" + r1 + " | StringBuffer length=" + r2);
        }
    }
}
