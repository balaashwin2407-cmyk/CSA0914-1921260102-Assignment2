# Q1: Building Text Under Load: String, StringBuilder or StringBuffer

Main classes: StringBench, SharedLogDemo

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: + is 1.5x/4.1x/49x slower than StringBuilder on workloads A/B/C and allocates up to 163x more; StringBuilder loses data when shared between threads (800,000 of 1,600,000 in one trial, an exception in another); StringBuffer was always correct.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
