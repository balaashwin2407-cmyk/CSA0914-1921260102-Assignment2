import java.lang.management.ManagementFactory;
import java.util.StringJoiner;

public class StringBench {
    static final com.sun.management.ThreadMXBean TB =
            (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static long alloc() { return TB.getThreadAllocatedBytes(Thread.currentThread().getId()); }

    static String[] fields(int n) {
        String[] f = new String[n];
        for (int i = 0; i < n; i++) f[i] = "F" + i + "=V" + (i * 7 % 100) + ";";   // about 9-10 chars
        return f;
    }
    static String plus(String[] f)    { String s = ""; for (String x : f) s += x; return s; }
    static String builder(String[] f) { StringBuilder b = new StringBuilder(); for (String x : f) b.append(x); return b.toString(); }
    static String buffer(String[] f)  { StringBuffer b = new StringBuffer(); for (String x : f) b.append(x); return b.toString(); }
    static String join(String[] f)    { return String.join("", f); }
    static String joiner(String[] f)  { StringJoiner j = new StringJoiner(""); for (String x : f) j.add(x); return j.toString(); }
    static String format(String[] f)  { return String.format("%s".repeat(f.length), (Object[]) f); }

    interface Method { String build(String[] f); }
    static long sink = 0;

    static void run(String workload, int tickets, int nFields, int reps, String[] names, Method[] ms) {
        String[] f = fields(nFields);
        for (int m = 0; m < ms.length; m++) {
            for (int w = 0; w < 2; w++) for (int t = 0; t < Math.min(tickets, 200); t++) sink += ms[m].build(f).length(); // warm-up
            double sum = 0, min = 1e18; long allocBytes = 0;
            for (int r = 0; r < reps; r++) {
                long a0 = alloc(), t0 = System.nanoTime();
                for (int t = 0; t < tickets; t++) sink += ms[m].build(f).length();
                double ms_ = (System.nanoTime() - t0) / 1e6;
                allocBytes = alloc() - a0;
                sum += ms_; min = Math.min(min, ms_);
            }
            System.out.printf("ROW,%s,%d,%d,%s,%.2f,%.2f,%.1f%n", workload, tickets, nFields, names[m], sum / reps, min, allocBytes / 1e6);
        }
    }
    public static void main(String[] args) {
        String[] names = {"plus(+=)", "StringBuilder", "StringBuffer", "String.join", "StringJoiner", "String.format"};
        Method[] ms = {StringBench::plus, StringBench::builder, StringBench::buffer, StringBench::join, StringBench::joiner, StringBench::format};
        System.out.println("ROW,workload,tickets,fields,approach,avg_ms,min_ms,alloc_MB_per_run");
        run("A short ticket", 100_000, 10, 5, names, ms);
        run("B bulk", 10_000, 50, 5, names, ms);
        run("C long ticket", 100, 1_000, 3, names, ms);
        System.out.println("# estimate of intermediate String objects per ticket and chars copied (L = 9.5 chars per field)");
        for (int n : new int[]{10, 50, 1000}) {
            double L = 9.5;
            System.out.printf("EST,n=%d,plus: intermediate Strings=%d, chars copied=%.0f | builder: intermediate Strings=0 (1 final), chars copied=about %.0f%n",
                    n, n - 1, L * n * (n + 1) / 2.0, 2 * L * n);
        }
        System.out.println("# checksum " + sink);
    }
}
