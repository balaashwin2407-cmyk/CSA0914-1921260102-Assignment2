# Q3: Engineer the hashCode-equals Contract

Main classes: Attendance (Complete the Code), HashContractTests; before/Attendance is the version without TODO 1

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: Without hashCode the program prints 3 unique students; with the fix it prints 2. All 10 predictions in HashContractTests matched.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
