import java.util.*;

class BrokenStudent {                                   // equals() only, no hashCode()
    final String regNo, name;
    BrokenStudent(String r, String n) { regNo = r; name = n; }
    @Override public boolean equals(Object o) { return o instanceof BrokenStudent && regNo.equals(((BrokenStudent) o).regNo); }
}
class GoodStudent {                                     // equals() and hashCode() on the same field
    final String regNo, name;
    GoodStudent(String r, String n) { regNo = r; name = n; }
    @Override public boolean equals(Object o) { return o instanceof GoodStudent && regNo.equals(((GoodStudent) o).regNo); }
    @Override public int hashCode() { return regNo.hashCode(); }
}
class MutableStudent {                                  // hashCode depends on a field that can change
    String regNo; final String name;
    MutableStudent(String r, String n) { regNo = r; name = n; }
    @Override public boolean equals(Object o) { return o instanceof MutableStudent && regNo.equals(((MutableStudent) o).regNo); }
    @Override public int hashCode() { return regNo.hashCode(); }
}
class NamedStudent implements Comparable<NamedStudent> { // compareTo (by name) inconsistent with equals (by regNo)
    final String regNo, name;
    NamedStudent(String r, String n) { regNo = r; name = n; }
    @Override public boolean equals(Object o) { return o instanceof NamedStudent && regNo.equals(((NamedStudent) o).regNo); }
    @Override public int hashCode() { return regNo.hashCode(); }
    @Override public int compareTo(NamedStudent o) { return name.compareTo(o.name); }
}

public class HashContractTests {
    static int ok = 0, total = 0;
    static void report(String test, int predicted, int actual, String why) {
        total++; if (predicted == actual) ok++;
        System.out.printf("%-58s predicted=%-5d actual=%-5d %s%n   reason: %s%n", test, predicted, actual, predicted == actual ? "MATCH" : "DIFFERENT", why);
    }
    public static void main(String[] args) {
        System.out.println("=== Test 1: set that APPEARS to work (the same card object scanned twice) ===");
        BrokenStudent arun = new BrokenStudent("192311001", "Arun");
        Set<BrokenStudent> t1 = new HashSet<>(); t1.add(arun); t1.add(new BrokenStudent("192311002", "Divya")); t1.add(arun);
        report("T1 HashSet<BrokenStudent>, same object reference twice", 2, t1.size(), "same reference gives the same identity hash and equals(this)=true, so the 2nd add is rejected");
        Set<GoodStudent> t1b = new HashSet<>(); GoodStudent a2 = new GoodStudent("192311001", "Arun");
        t1b.add(a2); t1b.add(new GoodStudent("192311002", "Divya")); t1b.add(a2);
        report("T1b HashSet<GoodStudent>, same object reference twice", 2, t1b.size(), "works with or without a correct hashCode()");

        System.out.println("\n=== Test 2: deliberately exposing duplicates (new object per scan) ===");
        Set<BrokenStudent> t2 = new HashSet<>();
        t2.add(new BrokenStudent("192311001", "Arun")); t2.add(new BrokenStudent("192311002", "Divya")); t2.add(new BrokenStudent("192311001", "Arun"));
        report("T2 HashSet<BrokenStudent>, 3 scans of 2 students", 3, t2.size(), "equal objects get different identity hashCodes, land in different buckets, equals() is never called");
        Set<GoodStudent> t2b = new HashSet<>();
        t2b.add(new GoodStudent("192311001", "Arun")); t2b.add(new GoodStudent("192311002", "Divya")); t2b.add(new GoodStudent("192311001", "Arun"));
        report("T2b HashSet<GoodStudent>, same 3 scans", 2, t2b.size(), "equal objects share a hashCode, same bucket, equals() confirms duplicate");
        Set<BrokenStudent> big = new HashSet<>(); Set<GoodStudent> bigGood = new HashSet<>();
        for (int g = 0; g < 3; g++) for (int i = 0; i < 1000; i++) { String r = "R" + i; big.add(new BrokenStudent(r, "S" + i)); bigGood.add(new GoodStudent(r, "S" + i)); }
        report("T2c 1000 students scanned at 3 gates, BrokenStudent", 3000, big.size(), "every scan is stored as a 'new' student");
        report("T2c 1000 students scanned at 3 gates, GoodStudent", 1000, bigGood.size(), "duplicates removed");
        System.out.println("contains() on BrokenStudent set for an equal object: " + big.contains(new BrokenStudent("R5", "x")) + " (predicted false)");

        System.out.println("\n=== Test 3: field used in hashCode() changed after insertion ===");
        Set<MutableStudent> t3 = new HashSet<>(); MutableStudent m = new MutableStudent("A1", "Ravi"); t3.add(m); m.regNo = "A2";
        report("T3 size after changing regNo", 1, t3.size(), "the element is still in the set");
        System.out.println("   contains(m) = " + t3.contains(m) + " (predicted false: lookup hashes A2, but the entry sits in the bucket for A1)");
        System.out.println("   remove(m)   = " + t3.remove(m) + " (predicted false: element is orphaned, size stays " + t3.size() + ")");
        t3.add(new MutableStudent("A2", "Ravi"));
        report("T3b add an equal student after the change", 2, t3.size(), "the orphaned entry is invisible to lookup, so a duplicate is accepted");

        System.out.println("\n=== Test 4: TreeSet whose compareTo() is inconsistent with equals() ===");
        NamedStudent s1 = new NamedStudent("101", "Asha"), s2 = new NamedStudent("102", "Asha");
        report("T4 HashSet<NamedStudent>: two regNo, same name", 2, new HashSet<>(List.of(s1, s2)).size(), "equals() uses regNo: different students");
        TreeSet<NamedStudent> ts = new TreeSet<>(); ts.add(s1); ts.add(s2);
        report("T4 TreeSet<NamedStudent> (compareTo by name)", 1, ts.size(), "TreeSet uses compareTo()==0 as 'equal', so the 2nd student is silently dropped");

        System.out.println("\nPredictions matched: " + ok + " of " + total);
        System.out.println("\n=== Alternative designs: time per scan (3 scans per unique student, average of 10 runs) ===");
        System.out.println("ROW,unique_students,structure,ns_per_scan");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            String[] ids = new String[n]; for (int i = 0; i < n; i++) ids[i] = String.format("19%07d", i);
            double[] t = new double[3];
            for (int rep = 0; rep < 16; rep++) {
                long a = System.nanoTime(); Set<GoodStudent> hs = new HashSet<>();
                for (int g = 0; g < 3; g++) for (String id : ids) hs.add(new GoodStudent(id, "x"));
                long b = System.nanoTime(); Set<GoodStudent> tr = new TreeSet<>(Comparator.comparing((GoodStudent s) -> s.regNo));
                for (int g = 0; g < 3; g++) for (String id : ids) tr.add(new GoodStudent(id, "x"));
                long c = System.nanoTime(); Map<String, GoodStudent> hm = new HashMap<>();
                for (int g = 0; g < 3; g++) for (String id : ids) hm.putIfAbsent(id, new GoodStudent(id, "x"));
                long d = System.nanoTime();
                if (rep > 5) { t[0] += b - a; t[1] += c - b; t[2] += d - c; }
                if (hs.size() != n || tr.size() != n || hm.size() != n) throw new IllegalStateException("dedup failed");
            }
            String[] nm = {"HashSet<Student>", "TreeSet<Student> (comparator on regNo)", "HashMap<String,Student> keyed by regNo"};
            for (int k = 0; k < 3; k++) System.out.printf("ROW,%d,%s,%.1f%n", n, nm[k], t[k] / 10 / (3.0 * n));
        }
    }
}
