# Q4: Choosing a Map for a Pharmacy Inventory

Main classes: MapBench

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: Hash-based maps look up in tens of ns, TreeMap in hundreds of ns, binarySearch in about 1 microsecond; LinkedHashMap chosen; every report order verified.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
