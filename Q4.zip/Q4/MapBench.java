import java.util.*;

public class MapBench {
    static long sink = 0;
    record Medicine(String code, int stock) {}

    static String report(Collection<Map.Entry<String, Integer>> es) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : es) sb.append(e.getKey()).append(':').append(e.getValue()).append('\n');
        return sb.toString();
    }
    static String codeOrderReport(Map<String, Integer> m, boolean sorted) {
        if (sorted) return report(m.entrySet());                       // TreeMap: already in order
        List<Map.Entry<String, Integer>> l = new ArrayList<>(m.entrySet());   // extra work: copy + sort
        l.sort(Map.Entry.comparingByKey());
        return report(l);
    }
    public static void main(String[] args) {
        System.out.println("ROW,medicines,map,put_all_ms,100k_lookups_ms,ns_per_lookup,code_report_ms,insertion_report_ms,code_order_ok,insertion_order_ok");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            List<String> insertion = new ArrayList<>(n);
            for (int i = 0; i < n; i++) insertion.add(String.format("MED%06d", i));
            Collections.shuffle(insertion, new Random(1));                     // codes arrive in random order
            List<String> sortedCodes = new ArrayList<>(insertion); Collections.sort(sortedCodes);
            Random rnd = new Random(2); String[] probes = new String[100_000];
            for (int i = 0; i < probes.length; i++) probes[i] = insertion.get(rnd.nextInt(n));
            String expectedCode = null, expectedIns = null;
            String[] names = {"HashMap", "TreeMap", "LinkedHashMap", "Hashtable"}; System.gc();
            for (int k = 0; k < 4; k++) {
                double put = 0, look = 0, repC = 0, repI = 0; boolean okC = false, okI = false;
                for (int rep = 0; rep < 12; rep++) {
                    Map<String, Integer> m = k == 0 ? new HashMap<>() : k == 1 ? new TreeMap<>() : k == 2 ? new LinkedHashMap<>() : new Hashtable<>();
                    long t0 = System.nanoTime();
                    for (String c : insertion) m.put(c, c.hashCode() & 255);
                    long t1 = System.nanoTime();
                    long s = 0; for (String p : probes) s += m.get(p); sink += s;
                    long t2 = System.nanoTime();
                    String rc = k == 3 ? "" : codeOrderReport(m, k == 1);
                    long t3 = System.nanoTime();
                    String ri;
                    if (k == 2) ri = report(m.entrySet());
                    else if (k == 3) ri = "";
                    else { StringBuilder sb = new StringBuilder(); for (String c : insertion) sb.append(c).append(':').append(m.get(c)).append('\n'); ri = sb.toString(); } // needs a parallel insertion list
                    long t4 = System.nanoTime();
                    if (rep > 3) { put += t1 - t0; look += t2 - t1; repC += t3 - t2; repI += t4 - t3; }
                    if (rep == 11 && k != 3) {
                        StringBuilder a = new StringBuilder(), b = new StringBuilder();
                        for (String c : sortedCodes) a.append(c).append(':').append(m.get(c)).append('\n');
                        for (String c : insertion) b.append(c).append(':').append(m.get(c)).append('\n');
                        okC = rc.equals(a.toString()); okI = ri.equals(b.toString());
                    }
                }
                System.out.printf("ROW,%d,%s,%.2f,%.2f,%.1f,%s,%s,%s,%s%n", n, names[k], put / 8 / 1e6, look / 8 / 1e6, look / 8 / probes.length,
                        k == 3 ? "n/a" : String.format("%.2f", repC / 8 / 1e6), k == 3 ? "n/a" : String.format("%.2f", repI / 8 / 1e6), k == 3 ? "n/a" : okC, k == 3 ? "n/a" : okI);
            }
            // sorted array + Arrays.binarySearch
            double build = 0, look = 0, ins = 0, rep = 0;
            for (int r = 0; r < 12; r++) {
                long t0 = System.nanoTime();
                Medicine[] arr = new Medicine[n]; for (int i = 0; i < n; i++) arr[i] = new Medicine(sortedCodes.get(i), i & 255);
                long t1 = System.nanoTime();
                long s = 0; for (String p : probes) { int ix = Arrays.binarySearch(arr, new Medicine(p, 0), Comparator.comparing(Medicine::code)); s += arr[ix].stock(); } sink += s;
                long t2 = System.nanoTime();
                int inserts = Math.min(1000, n);                                  // insert new codes in sorted position (shifting)
                Medicine[] grow = Arrays.copyOf(arr, n + inserts); int size = n; Random rr = new Random(5);
                for (int i = 0; i < inserts; i++) {
                    Medicine nm = new Medicine(String.format("MED%06dX", rr.nextInt(n)), 1);
                    int pos = Arrays.binarySearch(grow, 0, size, nm, Comparator.comparing(Medicine::code)); if (pos < 0) pos = -pos - 1;
                    System.arraycopy(grow, pos, grow, pos + 1, size - pos); grow[pos] = nm; size++;
                }
                long t3 = System.nanoTime();
                StringBuilder sb = new StringBuilder(); for (Medicine md : arr) sb.append(md.code()).append(':').append(md.stock()).append('\n'); sink += sb.length();
                long t4 = System.nanoTime();
                if (r > 3) { build += t1 - t0; look += t2 - t1; ins += (t3 - t2) / (double) inserts; rep += t4 - t3; }
            }
            System.out.printf("ARR,%d,sorted array+binarySearch,build_ms=%.2f,100k_lookups_ms=%.2f,ns_per_lookup=%.1f,us_per_insert=%.2f,code_report_ms=%.2f%n",
                    n, build / 8 / 1e6, look / 8 / 1e6, look / 8 / 100_000, ins / 8 / 1e3, rep / 8 / 1e6);
        }
        System.out.println("# checksum " + sink);
    }
}
