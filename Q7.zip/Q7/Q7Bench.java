import java.lang.management.ManagementFactory;
import java.util.*;

public class Q7Bench {
    static final com.sun.management.ThreadMXBean TB = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static long alloc() { return TB.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static long sink = 0;
    // mix: 30% addLast, 20% addFirst, 25% removeFirst, 10% insert middle, 15% get(k)
    static int[] script(int ops) { Random r = new Random(77); int[] s = new int[ops]; for (int i = 0; i < ops; i++) { int x = r.nextInt(100);
        s[i] = x < 30 ? 0 : x < 50 ? 1 : x < 75 ? 2 : x < 85 ? 3 : 4; } return s; }

    public static void main(String[] args) {
        System.out.println("ROW,operations,structure,avg_ms,min_ms,element_moves,alloc_MB");
        String[] names = {"java.util.ArrayList", "LinkedList", "RingList (redesign)"};
        for (int ops : new int[]{20_000, 50_000, 100_000}) {
            int[] sc = script(ops);
            for (int s = 0; s < 3; s++) {
                double sum = 0, min = 1e18, mb = 0; long moves = 0;
                for (int rep = 0; rep < 5; rep++) {
                    ArrayList<Integer> al = new ArrayList<>(); LinkedList<Integer> ll = new LinkedList<>(); RingList<Integer> rl = new RingList<>(); SimpleArrayList<Integer> counter = new SimpleArrayList<>();
                    for (int i = 0; i < 10_000; i++) { al.add(i); ll.add(i); rl.addLast(i); counter.addLast(i); }
                    rl.moves = 0; counter.moves = 0;
                    Random kr = new Random(5);
                    long a0 = alloc(), t0 = System.nanoTime();
                    for (int i = 0; i < ops; i++) {
                        int op = sc[i];
                        if (s == 0) { switch (op) { case 0 -> al.add(i); case 1 -> al.add(0, i); case 2 -> { if (!al.isEmpty()) sink += al.remove(0); }
                            case 3 -> al.add(al.size() / 2, i); default -> { if (!al.isEmpty()) sink += al.get(kr.nextInt(al.size())); } } }
                        else if (s == 1) { switch (op) { case 0 -> ll.addLast(i); case 1 -> ll.addFirst(i); case 2 -> { if (!ll.isEmpty()) sink += ll.removeFirst(); }
                            case 3 -> ll.add(ll.size() / 2, i); default -> { if (!ll.isEmpty()) sink += ll.get(kr.nextInt(ll.size())); } } }
                        else { switch (op) { case 0 -> rl.addLast(i); case 1 -> rl.addFirst(i); case 2 -> { if (rl.size() > 0) sink += rl.removeFirst(); }
                            case 3 -> rl.add(rl.size() / 2, i); default -> { if (rl.size() > 0) sink += rl.get(kr.nextInt(rl.size())); } } }
                    }
                    double ms = (System.nanoTime() - t0) / 1e6; double alloc = (alloc() - a0) / 1e6;
                    if (rep > 0) { sum += ms; min = Math.min(min, ms); mb += alloc; }
                    if (s == 2) moves = rl.moves;
                }
                // element moves for an ArrayList-style array: replay the same script on the counting baseline
                if (s == 0) { SimpleArrayList<Integer> c = new SimpleArrayList<>(); for (int i = 0; i < 10_000; i++) c.addLast(i); c.moves = 0; Random kr = new Random(5);
                    for (int i = 0; i < ops; i++) { switch (sc[i]) { case 0 -> c.addLast(i); case 1 -> c.addFirst(i); case 2 -> { if (c.size() > 0) c.removeFirst(); }
                        case 3 -> c.add(c.size() / 2, i); default -> { if (c.size() > 0) c.get(kr.nextInt(c.size())); } } } moves = c.moves; }
                System.out.printf("ROW,%d,%s,%.2f,%.2f,%s,%.1f%n", ops, names[s], sum / 4, min, s == 1 ? "n/a (pointer hops)" : String.valueOf(moves), mb / 4);
            }
        }
        System.out.println("# checksum " + sink);
    }
}
