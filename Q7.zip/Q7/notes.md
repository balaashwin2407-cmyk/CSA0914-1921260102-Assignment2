# Q7: Diagnose, Redesign and Validate

Main classes: RingListTest, Q7Bench (RingList is the redesign)

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: RingList: 0 mismatches against ArrayList in 300,000 random operations; about 10x fewer element moves and 4x to 17x faster than ArrayList on the mixed Up Next workload.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
