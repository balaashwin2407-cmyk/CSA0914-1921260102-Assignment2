import java.util.Arrays;

/** Baseline that behaves like java.util.ArrayList but counts element moves. */
public class SimpleArrayList<E> {
    private Object[] a = new Object[16]; private int size = 0; long moves = 0;
    public int size() { return size; }
    @SuppressWarnings("unchecked") public E get(int i) { if (i < 0 || i >= size) throw new IndexOutOfBoundsException(); return (E) a[i]; }
    public void add(int i, E e) { if (size == a.length) a = Arrays.copyOf(a, size * 2);
        System.arraycopy(a, i, a, i + 1, size - i); moves += size - i; a[i] = e; size++; }
    public void addLast(E e) { add(size, e); }
    public void addFirst(E e) { add(0, e); }
    @SuppressWarnings("unchecked") public E remove(int i) { E e = (E) a[i]; System.arraycopy(a, i + 1, a, i, size - i - 1); moves += size - i - 1; a[--size] = null; return e; }
    public E removeFirst() { return remove(0); }
}
