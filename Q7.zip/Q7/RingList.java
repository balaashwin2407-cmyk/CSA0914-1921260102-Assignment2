import java.util.NoSuchElementException;

/** Circular-buffer list: O(1) get/set, O(1) at both ends, middle insert shifts only the SHORTER side. */
public class RingList<E> {
    private Object[] buf = new Object[16];     // capacity is always a power of two so (x & mask) wraps around
    private int head = 0, size = 0;
    long moves = 0;                            // element moves, for operation-count evidence

    private int idx(int i) { return (head + i) & (buf.length - 1); }
    public int size() { return size; }
    private void check(int i, int limit) { if (i < 0 || i >= limit) throw new IndexOutOfBoundsException("index " + i + ", size " + size); }

    @SuppressWarnings("unchecked") public E get(int i) { check(i, size); return (E) buf[idx(i)]; }
    @SuppressWarnings("unchecked") public E set(int i, E e) { check(i, size); E old = (E) buf[idx(i)]; buf[idx(i)] = e; return old; }

    private void grow() {
        Object[] nb = new Object[buf.length * 2];
        for (int i = 0; i < size; i++) nb[i] = buf[idx(i)];
        buf = nb; head = 0;
    }
    public void addLast(E e) { if (size == buf.length) grow(); buf[idx(size)] = e; size++; }
    public void addFirst(E e) { if (size == buf.length) grow(); head = (head - 1) & (buf.length - 1); buf[head] = e; size++; }
    @SuppressWarnings("unchecked") public E removeFirst() {
        if (size == 0) throw new NoSuchElementException();
        E e = (E) buf[head]; buf[head] = null; head = (head + 1) & (buf.length - 1); size--; return e;
    }
    @SuppressWarnings("unchecked") public E removeLast() {
        if (size == 0) throw new NoSuchElementException();
        int p = idx(size - 1); E e = (E) buf[p]; buf[p] = null; size--; return e;
    }
    /** moves logical [from, from+count) one step toward the tail; block copy when the range does not wrap */
    private void shiftRight(int from, int count) {
        if (count <= 0) return;
        int s = idx(from), e = idx(from + count);
        if (s < e) System.arraycopy(buf, s, buf, s + 1, count);
        else for (int k = from + count; k > from; k--) buf[idx(k)] = buf[idx(k - 1)];
        moves += count;
    }
    /** moves logical [from, from+count) one step toward the head */
    private void shiftLeft(int from, int count) {
        if (count <= 0) return;
        int d = idx(from - 1), s = idx(from), e = idx(from + count - 1);
        if (e > d) System.arraycopy(buf, s, buf, d, count);
        else for (int k = from; k < from + count; k++) buf[idx(k - 1)] = buf[idx(k)];
        moves += count;
    }
    public void add(int i, E e) {
        if (i < 0 || i > size) throw new IndexOutOfBoundsException("index " + i + ", size " + size);
        if (size == buf.length) grow();
        if (i < size / 2) {                                    // shift the shorter, front part toward the head
            head = (head - 1) & (buf.length - 1);
            shiftLeft(1, i);
        } else {                                               // shift the shorter, back part toward the tail
            shiftRight(i, size - i);
        }
        buf[idx(i)] = e; size++;
    }
    @SuppressWarnings("unchecked") public E remove(int i) {
        check(i, size);
        E e = (E) buf[idx(i)];
        if (i < size / 2) {
            shiftRight(0, i);
            buf[head] = null; head = (head + 1) & (buf.length - 1);
        } else {
            shiftLeft(i + 1, size - i - 1);
            buf[idx(size - 1)] = null;
        }
        size--; return e;
    }
}
