import java.util.*;

public class RingListTest {
    public static void main(String[] args) {
        Random r = new Random(123); RingList<Integer> ring = new RingList<>(); ArrayList<Integer> ref = new ArrayList<>();
        int ops = 300_000, mismatches = 0;
        for (int i = 0; i < ops; i++) {
            int op = r.nextInt(8), n = ref.size();
            switch (op) {
                case 0 -> { ring.addLast(i); ref.add(i); }
                case 1 -> { ring.addFirst(i); ref.add(0, i); }
                case 2 -> { int p = r.nextInt(n + 1); ring.add(p, i); ref.add(p, i); }
                case 3 -> { if (n > 0) { if (!ring.removeFirst().equals(ref.remove(0))) mismatches++; } }
                case 4 -> { if (n > 0) { if (!ring.removeLast().equals(ref.remove(n - 1))) mismatches++; } }
                case 5 -> { if (n > 0) { int p = r.nextInt(n); if (!ring.remove(p).equals(ref.remove(p))) mismatches++; } }
                case 6 -> { if (n > 0) { int p = r.nextInt(n); if (!ring.get(p).equals(ref.get(p))) mismatches++; } }
                default -> { if (n > 0) { int p = r.nextInt(n); ring.set(p, -i); ref.set(p, -i); } }
            }
            if (ring.size() != ref.size()) mismatches++;
        }
        for (int i = 0; i < ref.size(); i++) if (!ring.get(i).equals(ref.get(i))) mismatches++;
        System.out.println("Property test: " + ops + " random operations vs java.util.ArrayList, final size " + ref.size() + ", mismatches = " + mismatches);
        try { ring.get(ref.size()); System.out.println("bounds check: FAIL"); } catch (IndexOutOfBoundsException e) { System.out.println("bounds check: OK (IndexOutOfBoundsException)"); }
    }
}
