import java.util.*;

public class TriageTests {
    static long sink;
    static final Comparator<Patient> RULE = Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival);

    // alternative 1: LinkedList kept sorted, insert at correct position
    static class SortedLinked {
        final LinkedList<Patient> l = new LinkedList<>();
        void add(Patient p) { ListIterator<Patient> it = l.listIterator(); while (it.hasNext()) { if (RULE.compare(it.next(), p) > 0) { it.previous(); break; } } it.add(p); }
        Patient next() { return l.pollFirst(); }
    }
    // alternative 2: five FIFO queues, one per severity
    static class FiveQueues {
        @SuppressWarnings("unchecked") final ArrayDeque<Patient>[] q = new ArrayDeque[6];
        FiveQueues() { for (int i = 1; i <= 5; i++) q[i] = new ArrayDeque<>(); }
        void add(Patient p) { q[p.severity].addLast(p); }
        Patient next() { for (int s = 1; s <= 5; s++) if (!q[s].isEmpty()) return q[s].pollFirst(); return null; }
    }
    public static void main(String[] args) {
        for (int w = 0; w < 40; w++) { PriorityQueue<Patient> q = new PriorityQueue<>(RULE); for (int i = 0; i < 20000; i++) q.add(new Patient("W", 1 + i % 5, i)); while (q.poll() != null) sink++; }  // JIT warm-up
        System.out.println("=== Correctness check: 8 patients, order derived by hand ===");
        String[] names = {"Ravi", "Meena", "John", "Asha", "Kumar", "Lata", "Dev", "Sita"}; int[] sev = {3, 1, 3, 5, 1, 2, 2, 4};
        PriorityQueue<Patient> pq = new PriorityQueue<>(RULE);
        for (int i = 0; i < 8; i++) pq.add(new Patient(names[i], sev[i], i));
        System.out.println("arrival order      : Ravi(3) Meena(1) John(3) Asha(5) Kumar(1) Lata(2) Dev(2) Sita(4)");
        System.out.println("hand-derived order : Meena(S1) Kumar(S1) Lata(S2) Dev(S2) Ravi(S3) John(S3) Sita(S4) Asha(S5)");
        System.out.println("println(pq) shows  : " + pq + "   <- heap array order, NOT treatment order");
        StringBuilder sb = new StringBuilder(); Patient p; while ((p = pq.poll()) != null) sb.append(p).append(' ');
        System.out.println("poll() order       : " + sb.toString().trim());
        System.out.println("matches hand-derived: " + sb.toString().trim().equals("Meena(S1) Kumar(S1) Lata(S2) Dev(S2) Ravi(S3) John(S3) Sita(S4) Asha(S5)"));
        System.out.println("waiting list in treatment order without removing: " + sortedView(names, sev));

        System.out.println("\n=== Growth: cost of admit and next (average ns per operation, 10 to 2000 repeated runs depending on n) ===");
        System.out.println("ROW,n,structure,admit_ns,next_ns");
        Random rnd = new Random(11);
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            Patient[] ps = new Patient[n]; for (int i = 0; i < n; i++) ps[i] = new Patient("P" + i, 1 + rnd.nextInt(5), i);
            double a = 0, b = 0; int REPS = Math.max(10, 2_000_000 / n);
            for (int rep = 0; rep < REPS + 1; rep++) { PriorityQueue<Patient> q = new PriorityQueue<>(RULE);
                long t0 = System.nanoTime(); for (Patient x : ps) q.add(x); long t1 = System.nanoTime(); while (q.poll() != null) sink++; long t2 = System.nanoTime();
                if (rep > 0) { a += t1 - t0; b += t2 - t1; } }
            System.out.printf("ROW,%d,PriorityQueue,%.1f,%.1f%n", n, a / REPS / n, b / REPS / n);
            a = 0; b = 0;
            for (int rep = 0; rep < REPS + 1; rep++) { FiveQueues q = new FiveQueues();
                long t0 = System.nanoTime(); for (Patient x : ps) q.add(x); long t1 = System.nanoTime(); while (q.next() != null) sink++; long t2 = System.nanoTime();
                if (rep > 0) { a += t1 - t0; b += t2 - t1; } }
            System.out.printf("ROW,%d,five FIFO queues,%.1f,%.1f%n", n, a / REPS / n, b / REPS / n);
            if (n <= 10_000) {
                a = 0; b = 0; int LREPS = n <= 1000 ? 60 : 6;
                for (int rep = 0; rep < LREPS + 1; rep++) { SortedLinked q = new SortedLinked();
                    long t0 = System.nanoTime(); for (Patient x : ps) q.add(x); long t1 = System.nanoTime(); while (q.next() != null) sink++; long t2 = System.nanoTime();
                    if (rep > 0) { a += t1 - t0; b += t2 - t1; } }
                System.out.printf("ROW,%d,sorted LinkedList,%.1f,%.1f%n", n, a / LREPS / n, b / LREPS / n);
            } else System.out.println("ROW," + n + ",sorted LinkedList,skipped (O(n) insert), ");
        }
        System.out.println("\n=== Deployment: one day of a city hospital (5,000 patients), admit all then serve all ===");
        Patient[] day = new Patient[5000]; for (int i = 0; i < 5000; i++) day[i] = new Patient("D" + i, 1 + rnd.nextInt(5), i);
        double tot = 0;
        for (int rep = 0; rep < 11; rep++) { PriorityQueue<Patient> q = new PriorityQueue<>(RULE); long t0 = System.nanoTime();
            for (Patient x : day) q.add(x); while (q.poll() != null) sink++; if (rep > 0) tot += System.nanoTime() - t0; }
        System.out.printf("5,000 admits + 5,000 treatments: %.3f ms total (average of 10 runs)%n", tot / 10 / 1e6);
        System.out.println("# checksum " + sink);
    }
    static String sortedView(String[] names, int[] sev) {
        List<Patient> l = new ArrayList<>(); for (int i = 0; i < names.length; i++) l.add(new Patient(names[i], sev[i], i)); l.sort(RULE); return l.toString();
    }
}
