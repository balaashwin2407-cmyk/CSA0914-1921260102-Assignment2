import java.util.*;

public class TriageAging {
    static class Aged { final String name; final int severity; final long arrival, key;
        Aged(String n, int s, long arrival, int[] delay) { name = n; severity = s; this.arrival = arrival; key = arrival + delay[s]; } }

    // returns the tick at which "Old" (severity 5, arrived at tick 0) is treated, or -1 if never within the horizon
    static long simulate(int[] delay, int horizon) {
        PriorityQueue<Aged> q = new PriorityQueue<>(Comparator.comparingLong((Aged a) -> a.key).thenComparingLong(a -> a.arrival));
        q.add(new Aged("Old", 5, 0, delay));
        for (long t = 1; t <= horizon; t++) {
            q.add(new Aged("C" + t, 1, t, delay));          // one critical patient arrives every tick
            Aged served = q.poll();                          // doctor treats exactly one patient per tick
            if (served.name.equals("Old")) return t;
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] strict = {0, 0, 0, 0, 0, 0};                   // key = arrival: that would be plain FIFO, so use severity-first below
        System.out.println("Strict severity-first rule (always S1 before S5): ");
        PriorityQueue<Patient> q = new PriorityQueue<>(Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival));
        q.add(new Patient("Old", 5, 0)); long servedOld = -1;
        for (long t = 1; t <= 100_000; t++) { q.add(new Patient("C" + t, 1, t)); if (q.poll().name.equals("Old")) { servedOld = t; break; } }
        System.out.println("  severity-5 patient treated at tick: " + (servedOld < 0 ? "NEVER within 100,000 ticks (starvation)" : servedOld));
        int[] delay = {0, 0, 10, 20, 30, 40};               // virtual deadline = arrival + delay[severity]
        System.out.println("Fair rule: key = arrival + delay[severity], delay = {S1:0, S2:10, S3:20, S4:30, S5:40} ticks");
        System.out.println("  severity-5 patient treated at tick: " + simulate(delay, 100_000));
        for (int d5 : new int[]{10, 40, 200}) { int[] dl = {0, 0, 5, 10, 20, d5};
            System.out.println("  with delay[S5]=" + d5 + " the S5 patient is treated at tick " + simulate(dl, 100_000)); }
        // same-severity order still preserved
        PriorityQueue<Aged> check = new PriorityQueue<>(Comparator.comparingLong((Aged a) -> a.key).thenComparingLong(a -> a.arrival));
        check.add(new Aged("first", 3, 0, delay)); check.add(new Aged("second", 3, 1, delay)); check.add(new Aged("third", 3, 2, delay));
        System.out.println("equal severity keeps arrival order: " + check.poll().name + ", " + check.poll().name + ", " + check.poll().name);
    }
}
