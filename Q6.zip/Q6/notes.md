# Q6: Priority, Order and Fairness in a Queue

Main classes: Triage (Complete the Code), TriageTests, TriageAging

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: Output matches expected; 8-patient hand check matches; starvation shown and fixed with virtual deadlines; 5,000 patients take about 1.3 ms.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
