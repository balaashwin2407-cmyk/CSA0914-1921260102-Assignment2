# Q2: When Is ArrayList an Appropriate Engineering Choice

Main classes: ListBench, UpNextBench

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: ArrayList: O(1) get and fast end add, but front edits cost 7.6 microseconds at 100,000 elements; LinkedList get(k) is about 520x slower; ArrayDeque is best for Up Next (0.96 ms vs 75.5 ms for 100,000 operations).

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
