import java.util.*;

public class UpNextBench {
    static long sink = 0;
    // workload: 40% add at end, 30% add at front, 30% remove from front (never from empty)
    static int[] script(int ops, long seed) {
        Random r = new Random(seed); int[] s = new int[ops];
        for (int i = 0; i < ops; i++) { int x = r.nextInt(10); s[i] = x < 4 ? 0 : (x < 7 ? 1 : 2); }
        return s;
    }
    public static void main(String[] args) {
        System.out.println("ROW,operations,structure,avg_ms,min_ms");
        for (int ops : new int[]{10_000, 50_000, 100_000}) {
            int[] sc = script(ops, 7);
            String[] names = {"ArrayList", "LinkedList", "ArrayDeque"};
            for (int s = 0; s < 3; s++) {
                double sum = 0, min = 1e18;
                for (int rep = 0; rep < 4; rep++) {
                    List<Integer> list = new ArrayList<>(); LinkedList<Integer> ll = new LinkedList<>(); ArrayDeque<Integer> ad = new ArrayDeque<>();
                    for (int i = 0; i < 1000; i++) { list.add(i); ll.add(i); ad.add(i); }
                    long t0 = System.nanoTime();
                    for (int i = 0; i < ops; i++) {
                        int op = sc[i];
                        if (s == 0) { if (op == 0) list.add(i); else if (op == 1) list.add(0, i); else if (!list.isEmpty()) sink += list.remove(0); }
                        else if (s == 1) { if (op == 0) ll.addLast(i); else if (op == 1) ll.addFirst(i); else if (!ll.isEmpty()) sink += ll.removeFirst(); }
                        else { if (op == 0) ad.addLast(i); else if (op == 1) ad.addFirst(i); else if (!ad.isEmpty()) sink += ad.removeFirst(); }
                    }
                    double ms = (System.nanoTime() - t0) / 1e6;
                    if (rep > 0) { sum += ms; min = Math.min(min, ms); }       // rep 0 = warm-up
                }
                System.out.printf("ROW,%d,%s,%.2f,%.2f%n", ops, names[s], sum / 3, min);
            }
        }
        System.out.println("# checksum " + sink);
    }
}
