import java.util.*;

public class ListBench {
    static long sink = 0;
    static int M = 2000;
    static final int REPS = 5;

    static Integer[] data(int n) { Integer[] a = new Integer[n]; for (int i = 0; i < n; i++) a[i] = i; return a; }

    static class ManualArray {
        int[] a = new int[16]; int size = 0;
        void add(int v) { if (size == a.length) a = Arrays.copyOf(a, size * 2); a[size++] = v; }
        void insert(int i, int v) { if (size == a.length) a = Arrays.copyOf(a, size * 2);
            for (int k = size; k > i; k--) a[k] = a[k - 1]; a[i] = v; size++; }
        void remove(int i) { for (int k = i; k < size - 1; k++) a[k] = a[k + 1]; size--; }
        int get(int i) { return a[i]; }
    }
    interface Op { void run(); }
    static double time(Op prepare, Op body, int perOps) {
        double sum = 0;
        for (int r = 0; r < REPS + 1; r++) {
            prepare.run();
            long t0 = System.nanoTime(); body.run(); long dt = System.nanoTime() - t0;
            if (r > 0) sum += dt;
        }
        return sum / REPS / perOps;
    }
    static void row(int n, String op, String structure, double ns) {
        System.out.printf("ROW,%d,%s,%s,%s%n", n, op, structure, ns < 0 ? "n/a" : String.format("%.1f", ns));
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        System.out.println("ROW,size,operation,structure,ns_per_op");
        Random rnd = new Random(42);
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            M = Math.min(2000, n / 2); Integer[] src = data(n);
            int[] ks = new int[M]; for (int i = 0; i < M; i++) ks[i] = rnd.nextInt(n);
            row(n, "add at end", "ArrayList", time(() -> {}, () -> { ArrayList<Integer> l = new ArrayList<>(); for (Integer x : src) l.add(x); sink += l.size(); }, n));
            row(n, "add at end", "LinkedList", time(() -> {}, () -> { LinkedList<Integer> l = new LinkedList<>(); for (Integer x : src) l.add(x); sink += l.size(); }, n));
            row(n, "add at end", "ArrayDeque", time(() -> {}, () -> { ArrayDeque<Integer> l = new ArrayDeque<>(); for (Integer x : src) l.addLast(x); sink += l.size(); }, n));
            row(n, "add at end", "manual array", time(() -> {}, () -> { ManualArray l = new ManualArray(); for (int i = 0; i < n; i++) l.add(i); sink += l.size; }, n));

            ArrayList<Integer>[] al = new ArrayList[1]; LinkedList<Integer>[] ll = new LinkedList[1]; ArrayDeque<Integer>[] ad = new ArrayDeque[1]; ManualArray[] ma = new ManualArray[1];
            Op prep = () -> { al[0] = new ArrayList<>(Arrays.asList(src)); ll[0] = new LinkedList<>(Arrays.asList(src)); ad[0] = new ArrayDeque<>(Arrays.asList(src));
                ma[0] = new ManualArray(); for (int i = 0; i < n; i++) ma[0].add(i); };
            row(n, "insert at front", "ArrayList", time(prep, () -> { for (int i = 0; i < M; i++) al[0].add(0, i); }, M));
            row(n, "insert at front", "LinkedList", time(prep, () -> { for (int i = 0; i < M; i++) ll[0].add(0, i); }, M));
            row(n, "insert at front", "ArrayDeque", time(prep, () -> { for (int i = 0; i < M; i++) ad[0].addFirst(i); }, M));
            row(n, "insert at front", "manual array", time(prep, () -> { for (int i = 0; i < M; i++) ma[0].insert(0, i); }, M));
            row(n, "insert in middle", "ArrayList", time(prep, () -> { for (int i = 0; i < M; i++) al[0].add(al[0].size() / 2, i); }, M));
            row(n, "insert in middle", "LinkedList", time(prep, () -> { for (int i = 0; i < M; i++) ll[0].add(ll[0].size() / 2, i); }, M));
            row(n, "insert in middle", "ArrayDeque", -1);
            row(n, "insert in middle", "manual array", time(prep, () -> { for (int i = 0; i < M; i++) ma[0].insert(ma[0].size / 2, i); }, M));
            row(n, "remove at front", "ArrayList", time(prep, () -> { for (int i = 0; i < M; i++) al[0].remove(0); }, M));
            row(n, "remove at front", "LinkedList", time(prep, () -> { for (int i = 0; i < M; i++) ll[0].remove(0); }, M));
            row(n, "remove at front", "ArrayDeque", time(prep, () -> { for (int i = 0; i < M; i++) ad[0].removeFirst(); }, M));
            row(n, "remove at front", "manual array", time(prep, () -> { for (int i = 0; i < M; i++) ma[0].remove(0); }, M));
            row(n, "remove in middle", "ArrayList", time(prep, () -> { for (int i = 0; i < M; i++) al[0].remove(al[0].size() / 2); }, M));
            row(n, "remove in middle", "LinkedList", time(prep, () -> { for (int i = 0; i < M; i++) ll[0].remove(ll[0].size() / 2); }, M));
            row(n, "remove in middle", "ArrayDeque", -1);
            row(n, "remove in middle", "manual array", time(prep, () -> { for (int i = 0; i < M; i++) ma[0].remove(ma[0].size / 2); }, M));
            row(n, "get k-th", "ArrayList", time(prep, () -> { for (int k : ks) sink += al[0].get(k); }, M));
            row(n, "get k-th", "LinkedList", time(prep, () -> { for (int k : ks) sink += ll[0].get(k); }, M));
            row(n, "get k-th", "ArrayDeque", -1);
            row(n, "get k-th", "manual array", time(prep, () -> { for (int k : ks) sink += ma[0].get(k); }, M));
            row(n, "iterate all", "ArrayList", time(prep, () -> { for (int x : al[0]) sink += x; }, n));
            row(n, "iterate all", "LinkedList", time(prep, () -> { for (int x : ll[0]) sink += x; }, n));
            row(n, "iterate all", "ArrayDeque", time(prep, () -> { for (int x : ad[0]) sink += x; }, n));
            row(n, "iterate all", "manual array", time(prep, () -> { for (int i = 0; i < ma[0].size; i++) sink += ma[0].a[i]; }, n));
        }
        System.out.println("# checksum " + sink);
    }
}
