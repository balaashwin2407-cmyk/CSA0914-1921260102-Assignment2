import java.util.*;

class BoundedBoard<T extends Comparable<? super T>> {          // bounded type: T must be rankable
    private final List<T> items = new ArrayList<>();
    void addAll(Collection<? extends T> more) { items.addAll(more); }   // wildcard: accepts List<Team>, List<SubTeam>...
    List<T> ranking() { List<T> c = new ArrayList<>(items); Collections.sort(c); return c; }
}
class ComparableTeam implements Comparable<ComparableTeam> {   // single natural order built into the class
    final String name; final int points, goalDiff;
    ComparableTeam(String n, int p, int g) { name = n; points = p; goalDiff = g; }
    @Override public int compareTo(ComparableTeam o) {
        int c = Integer.compare(o.points, points); if (c != 0) return c;
        c = Integer.compare(o.goalDiff, goalDiff); if (c != 0) return c;
        return name.compareTo(o.name);
    }
    @Override public String toString() { return name + "(" + points + "," + goalDiff + ")"; }
}
class CountingComparator<T> implements Comparator<T> {
    long count = 0; final Comparator<T> inner;
    CountingComparator(Comparator<T> c) { inner = c; }
    public int compare(T a, T b) { count++; return inner.compare(a, b); }
}

public class RankingTests {
    static final Comparator<Team> BY_RANK = Comparator.comparingInt((Team t) -> t.points).reversed()
            .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed()).thenComparing(t -> t.name);
    static final Comparator<Team> SUBTRACT = (a, b) -> b.points - a.points;                       // faulty: overflow
    static final Comparator<Team> NO_TIEBREAK = Comparator.comparingInt((Team t) -> t.points).reversed()
            .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed());          // faulty: ignores name
    static long sink;

    static List<Team> sorted(List<Team> in, Comparator<Team> c) { List<Team> l = new ArrayList<>(in); l.sort(c); return l; }

    static int transitivityViolations(List<Team> ts, Comparator<Team> c) {
        int bad = 0;
        for (Team a : ts) for (Team b : ts) for (Team d : ts)
            if (c.compare(a, b) < 0 && c.compare(b, d) < 0 && c.compare(a, d) >= 0) bad++;
        return bad;
    }
    public static void main(String[] args) {
        System.out.println("=== Data set 1: several ties at every level ===");
        List<Team> ds1 = List.of(new Team("Tigers", 9, 3), new Team("Lions", 12, 5), new Team("Hawks", 9, 3), new Team("Wolves", 9, 7),
                new Team("Sharks", 6, 2), new Team("Bears", 6, 2), new Team("Foxes", 12, 5), new Team("Owls", 12, 9), new Team("Zebras", 3, 0), new Team("Ants", 3, -1));
        String expected = "[Owls(12,9), Foxes(12,5), Lions(12,5), Wolves(9,7), Hawks(9,3), Tigers(9,3), Bears(6,2), Sharks(6,2), Zebras(3,0), Ants(3,-1)]";
        System.out.println("hand-derived: " + expected);
        System.out.println("comparator  : " + sorted(ds1, BY_RANK));
        System.out.println("match = " + expected.equals(sorted(ds1, BY_RANK).toString()));
        List<Team> shuffled = new ArrayList<>(ds1); boolean allSame = true;
        for (int s = 0; s < 1000; s++) { Collections.shuffle(shuffled, new Random(s)); if (!sorted(shuffled, BY_RANK).toString().equals(expected)) allSame = false; }
        System.out.println("same result for 1000 random input orders = " + allSame);
        System.out.println("transitivity violations (all triples) = " + transitivityViolations(ds1, BY_RANK));

        System.out.println("\n=== Data set 2: built to break faulty comparators ===");
        List<Team> ds2 = List.of(new Team("Max", Integer.MAX_VALUE, 0), new Team("Low", -5, 0), new Team("Zero", 0, 0), new Team("Big2", 2_000_000_000, 0), new Team("Neg", -2_000_000_000, 0));
        System.out.println("correct comparator : " + sorted(ds2, BY_RANK));
        System.out.println("subtraction (b-a)  : " + sorted(ds2, SUBTRACT) + "   <- overflow gives a wrong order");
        System.out.println("subtraction transitivity violations = " + transitivityViolations(ds2, SUBTRACT) + " (correct comparator: " + transitivityViolations(ds2, BY_RANK) + ")");
        List<Team> tie1 = List.of(new Team("Panthers", 9, 4), new Team("Bisons", 9, 4)), tie2 = List.of(new Team("Bisons", 9, 4), new Team("Panthers", 9, 4));
        System.out.println("no tie-break, input order 1: " + sorted(tie1, NO_TIEBREAK) + " | input order 2: " + sorted(tie2, NO_TIEBREAK) + "  <- depends on input order");
        System.out.println("full comparator, input 1   : " + sorted(tie1, BY_RANK) + " | input 2: " + sorted(tie2, BY_RANK));
        Random rnd = new Random(3); List<Team> many = new ArrayList<>();
        for (int i = 0; i < 5000; i++) many.add(new Team("T" + i, rnd.nextBoolean() ? rnd.nextInt(Integer.MAX_VALUE) : -rnd.nextInt(Integer.MAX_VALUE), 0));
        try { many.sort(SUBTRACT); System.out.println("5000 random extreme values with subtraction comparator: no exception, sorted correctly = " + isOrdered(many)); }
        catch (IllegalArgumentException e) { System.out.println("5000 random extreme values with subtraction comparator: List.sort threw IllegalArgumentException: " + e.getMessage()); }

        System.out.println("\n=== Comparable<ComparableTeam> and bounded generic board ===");
        BoundedBoard<ComparableTeam> bb = new BoundedBoard<>();
        List<ComparableTeam> cts = List.of(new ComparableTeam("Panthers", 9, 4), new ComparableTeam("Eagles", 9, 6), new ComparableTeam("Cobras", 6, 1), new ComparableTeam("Bisons", 9, 4));
        bb.addAll(cts);
        System.out.println(bb.ranking());

        System.out.println("\n=== Comparator chain (1 sort) vs three stable sorts (name, goalDiff, points) ===");
        System.out.println("ROW,n,approach,sorts,comparisons,avg_ms");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            Random r = new Random(9); List<Team> data = new ArrayList<>();
            for (int i = 0; i < n; i++) data.add(new Team("T" + r.nextInt(n), r.nextInt(30), r.nextInt(21) - 10));
            double t1 = 0, t3 = 0; long c1 = 0, c3 = 0; List<Team> o1 = null, o3 = null;
            for (int rep = 0; rep < 6; rep++) {
                CountingComparator<Team> cc = new CountingComparator<>(BY_RANK);
                List<Team> a = new ArrayList<>(data); long s0 = System.nanoTime(); a.sort(cc); long s1 = System.nanoTime();
                CountingComparator<Team> n1 = new CountingComparator<>(Comparator.comparing((Team t) -> t.name));
                CountingComparator<Team> n2 = new CountingComparator<>(Comparator.comparingInt((Team t) -> t.goalDiff).reversed());
                CountingComparator<Team> n3 = new CountingComparator<>(Comparator.comparingInt((Team t) -> t.points).reversed());
                List<Team> b = new ArrayList<>(data); long s2 = System.nanoTime(); b.sort(n1); b.sort(n2); b.sort(n3); long s3 = System.nanoTime();
                if (rep > 0) { t1 += s1 - s0; t3 += s3 - s2; }
                c1 = cc.count; c3 = n1.count + n2.count + n3.count; o1 = a; o3 = b;
            }
            boolean same = o1.toString().equals(o3.toString());
            System.out.printf("ROW,%d,comparator chain,1,%d,%.2f%n", n, c1, t1 / 5 / 1e6);
            System.out.printf("ROW,%d,three stable sorts,3,%d,%.2f%n", n, c3, t3 / 5 / 1e6);
            System.out.println("   identical final order = " + same);
        }
    }
    static boolean isOrdered(List<Team> l) { for (int i = 1; i < l.size(); i++) if (l.get(i - 1).points < l.get(i).points) return false; return true; }
}
