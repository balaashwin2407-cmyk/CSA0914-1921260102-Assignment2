# Q5: Derive a Generic Ranking Component from a Principle

Main classes: LeaderboardDemo (Complete the Code), RankingTests

Compile and run (inside this folder):
```
javac *.java
java <MainClass>
```

Result: Output matches expected: [Eagles(9,6), Bisons(9,4), Panthers(9,4), Cobras(6,1)]; subtraction comparator and missing tie-break break the principle as designed.

Raw experimental data: the raw_data_*.txt files. Output screenshots go in `screenshots/`.
